STEP 1: run "npm run install-server" to install all server dependencies



SETP 2: run "npm run install-client" to install all client dependencies



STEP 3: run "npm run seeds" to run seeds.js



STEP 4: run "npm run project" to start both server and client simultaneously




**LOGIN CREDENTIALS FROM SEEDS**

username: mark_rover
password: mark123

username: anthony_jr
password: anton123




-Arwen Christian Ceres