const mongoose = require("mongoose");

const mongooseConnect = () => {
  mongoose
    .connect("mongodb://localhost:27017/backend_ceres")
    .then((res) => console.log("Connection open"))
    .catch((err) => console.log("Connection failed", err.message));
};

module.exports = mongooseConnect;
